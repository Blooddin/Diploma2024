// Wi-Fi Network parameters
const char* ssid = "81";
const char* password = "you1974mom";
// ---------------------------------------